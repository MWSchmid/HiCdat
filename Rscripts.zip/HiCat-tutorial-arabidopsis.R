# set the path to the folder "tutorial" that has been created by unpacking the archive At.zip and the path to the folder with the scripts (the folder where the R-files are located)
pathToTutorial <- "/path/to/tutorial/At"
pathToScripts <- "/path/to/scripts"

# load all the necessary functions (general and organism specific)
library(HiCatR)
f.source.organism.specific.code(file.path(pathToScripts, "HiCat-A-thaliana-TAIR10.R"))

# set the binSize (there are only data for 100 kb bins available in the tutorial)
binSize <- 1e5

# specify the samples and their reduced matrices (see HiCat-map, "reduce matrix for R") 
sampleList <- list(Col = c("HiCat_subread_Col_100kb.txt"),
				   WT = c("HiCat_subread_WT_100kb.txt"),
				   crwn1 = c("HiCat_subread_crwn1_100kb.txt"),
				   crwn4 = c("HiCat_subread_crwn4_100kb.txt"),
				   morc = c("HiCat_subread_morc_100kb.txt"),
				   Col_combined = c("HiCat_subread_Col_100kb.txt", c("HiCat_subread_WT_100kb.txt"))
)

# load all samples into a list, access an individual HiC matrix with binMatList[[sampleName]] or binMatList$sampleName
binMatList <- f.load.samples(pathToTutorial, sampleList, binSize, 50)

# draw a sample correlation matrix
f.HiC.correlation.matrix(binMatList, pathToTutorial, outfile = "At")

# draw heatmaps of the raw interaction frequencies and the correlated interaction frequencies
f.plot.XY.matrix(binMatList[["Col_combined"]], binSize, 1e7, pathToTutorial, "HiC_raw_Col_combined")
f.plot.XY.matrix(binMatList[["Col_combined"]], binSize, 1e7, pathToTutorial, "HiC_cor_Col_combined", doCor = TRUE)

# calculate differences between two HiC samples of interest
test <- f.plot.signed.difference(binMatList[["Col"]], binMatList[["crwn4"]], binSize, pathToTutorial, "Diff_signed_Col_vs_crwn4", figureTitle = "Arabidopsis: Col-crwn4")
f.plot.relative.difference(binMatList[["Col"]], binMatList[["crwn4"]], binSize, pathToTutorial, "Diff_relative_Col_vs_crwn4")
f.plot.cor.difference(binMatList[["Col"]], binMatList[["crwn4"]], binSize, pathToTutorial, "Diff_correlated_Col_vs_crwn4")

# or calculate differences between all possible combinations of samples
test <- f.compare.samples.signed.difference(binMatList, binSize, pathToTutorial)
f.compare.samples.relative.difference(binMatList, binSize, pathToTutorial)
f.compare.samples.cor.difference(binMatList, binSize, pathToTutorial)

# calculate distance decay on the whole chromosomes or separately for the arms and the pericentromeres
definedGenomicRegionsArms <- read.table(file.path(pathToTutorial, "genomicRegionsArms_forDistanceDecay.txt"), sep = '\t', header = TRUE, quote = "", stringsAsFactors = FALSE)
definedGenomicRegionsPeri <- read.table(file.path(pathToTutorial, "genomicRegionsPeri_forDistanceDecay.txt"), sep = '\t', header = TRUE, quote = "", stringsAsFactors = FALSE)
test <- f.distance.decay(binMatList[["Col_combined"]], binSize, pathToTutorial, "distance_decay_Col_combined_full", 10e6)
test <- f.distance.decay(binMatList[["Col_combined"]], binSize, pathToTutorial, "distance_decay_Col_combined_arms", 5e6, definedGenomicRegionsArms)
test <- f.distance.decay(binMatList[["Col_combined"]], binSize, pathToTutorial, "distance_decay_Col_combined_peri", 1e6, definedGenomicRegionsPeri)

# read the annotation - it is either already in the right bin size or on fragments and needs to be summarized into bins
# for Arabidopsis, the approaches generally yield highly similar results
annotation <- f.read.annotation(file.path(pathToTutorial, "At_fragments_100kb_annotated.txt"), binSize)
annotationFromFragments <- f.read.annotation.via.fragment.annotation(file.path(pathToTutorial, "At_fragments_hindIII_annotated.txt"), binSize)

# test the input (which is from a ChIP-Seq experiment without using an antibody - is therefore like genomic sequencing and gives an idea about the alignability/mappability of the genome)
# compare it to the correlated HiC matrices - for Arabidopsis, the mappability is relatively uniform
input <- annotation[,"den_SRR094098_trimmed"]%*%t(annotation[,"den_SRR094098_trimmed"])
f.plot.XY.matrix(input, binSize, 1e7, pathToTutorial, "HiC_raw_INPUT_")
inputFromFragments <- annotationFromFragments[,"den_SRR094098_trimmed"]%*%t(annotationFromFragments[,"den_SRR094098_trimmed"])
f.plot.XY.matrix(inputFromFragments, binSize, 1e7, pathToTutorial, "HiC_raw_INPUT_FRAG")

# calculate the first principle component and relate it to genomic and epigenomic features
# NOTE that the sign of the first principle component is arbitrary - however, the function tries to turn it in a way that minus reflects more compact
definedGenomicRegionsArms <- read.table(file.path(pathToTutorial, "genomicRegionsArms_forPCA.txt"), sep = '\t', header = TRUE, quote = "", stringsAsFactors = FALSE)
test <- f.principle.component.analysis.and.features(binMatList[["Col_combined"]], binSize, pathToTutorial, "PCA_Col_combined_arms", annotationFromFragments, definedGenomicRegionsArms)

# test a certain set of bins for higher interaction 
toAdd <- 25e3 # specifies half the size of the region (is added on each side of the position in the table)
temp <- read.table(file.path(pathToTutorial, "KEE_positions.txt"), sep = '\t', header = TRUE, row.names = 1, stringsAsFactors = FALSE)
testRegions <- data.frame(chrom = temp$chrom, start = temp$pos - toAdd, end = temp$pos + toAdd, row.names = rownames(temp))
# using the whole genome
f.test.interaction.frequencies (binMatList[["Col_combined"]], binSize, 1e4, testRegions)
# splitting into arms at the centromere position
definedGenomicRegionsFullArms <- read.table(file.path(pathToTutorial, "genomicRegionsFullArms_forKEE.txt"), sep = '\t', header = TRUE, quote = "", stringsAsFactors = FALSE)
f.test.interaction.frequencies (binMatList[["Col_combined"]], binSize, 1e4, testRegions, definedGenomicRegionsFullArms)
# only using euchromatic parts of the arms
definedGenomicRegionsReducedArms <- read.table(file.path(pathToTutorial, "genomicRegionsReducedArms_forKEE.txt"), sep = '\t', header = TRUE, quote = "", stringsAsFactors = FALSE)
f.test.interaction.frequencies (binMatList[["Col_combined"]], binSize, 1e4, testRegions, definedGenomicRegionsReducedArms)



# an example for the normalization from Hu et al. 2012 (HiCnorm)
rawSamples <- f.load.samples(pathToTutorial, sampleList, binSize, 0)
annotation <- f.read.annotation(file.path(pathToTutorial, "At_fragments_hindIII_annotated.txt"), binSize)
annotation$length <- annotation$end-annotation$start
annotation$mappability <- annotation$den_artificialGenomeReads_sorted/100
annotation$gcContent <- annotation$den_fakeDNAmethylationTrackForCGcontent/100

normalizedSamples <- list()
for (sample in names(rawSamples)) {
	normalizedSamples[[sample]] <- f.normalize.like.hu(rawSamples[[sample]], binSize, annotation, "length", "gcContent", "mappability", useNegativeBinomial = FALSE)
}




